import pandas as pd

# Load the dataset
df = pd.read_csv("student_missing_values_raw.csv")

# 1. Missing-value summary
missing_summary = df.isna().sum()
print("=== MISSING VALUES BY COLUMN ===")
print(missing_summary)

print("\nTotal missing values:", df.isna().sum().sum())

# 2. Missing and non-missing checks
print("\n=== ISNA ===")
print(df.isna())

print("\n=== NOTNA ===")
print(df.notna())

# 3. Rows and columns affected
print("\n=== ROWS WITH MISSING VALUES ===")
print(df[df.isna().any(axis=1)])

print("\n=== COLUMNS WITH MISSING VALUES ===")
print(df.columns[df.isna().any()].tolist())

# 4. Drop incomplete rows
drop_rows = df.dropna()
print("\n=== AFTER DROPNA ===")
print(drop_rows)

# 5. Mean imputation for numerical columns
mean_df = df.copy()
for col in mean_df.select_dtypes(include="number").columns:
    mean_df[col] = mean_df[col].fillna(mean_df[col].mean())

# 6. Median imputation for numerical columns
median_df = df.copy()
for col in median_df.select_dtypes(include="number").columns:
    median_df[col] = median_df[col].fillna(median_df[col].median())

# 7. Mode imputation for categorical columns
mode_df = df.copy()
for col in mode_df.select_dtypes(include="object").columns:
    if mode_df[col].isna().any():
        mode_df[col] = mode_df[col].fillna(mode_df[col].mode()[0])

# 8. Final practical cleaning
cleaned = df.copy()

numeric_cols = cleaned.select_dtypes(include="number").columns
categorical_cols = cleaned.select_dtypes(include="object").columns

for col in numeric_cols:
    cleaned[col] = cleaned[col].fillna(cleaned[col].median())

for col in categorical_cols:
    if cleaned[col].isna().any():
        cleaned[col] = cleaned[col].fillna(cleaned[col].mode()[0])

print("\n=== CLEANED DATA ===")
print(cleaned)

print("\n=== REMAINING MISSING VALUES ===")
print(cleaned.isna().sum())

# Save cleaned data
cleaned.to_csv("student_missing_values_cleaned.csv", index=False)
